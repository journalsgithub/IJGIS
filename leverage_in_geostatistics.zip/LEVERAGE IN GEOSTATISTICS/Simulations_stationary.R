
#------------------------------------
# R code. Leverages in Geostatistics
#------------------------------------

#------------
# Libraries
#-----------

rm(list=ls())
library(geoR)
library(MASS)
#install.packages("pracma")
library(pracma)
library(ggplot2)
library(dplyr)

#--------------
# Coordinates
#--------------

# Plots in the article are generated using 4 options for set.seed (5, 20, 25, 15)
# You can change this option below to reproduce the plots in the article

# set.seed(5) 
# set.seed(20) 
# set.seed(25) 

set.seed(15) 
n_x=10
n_y=10
nsites = n_x*n_y
sites = cbind(runif(nsites,0,9), runif(nsites,0,9))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20) 

#------------------------
# Variogram parameters
#------------------------

mean=10                    # $\mu=10$
variance=4                 # $\sigma^2$
phi= 10                    # $\phi$      
nugget= 0                  # $\tao^2$          
model="exponential"          # variogram model
nsim=1                     # Only one  realization
nsites= length(sites[,1])  # Number of sites

#------------------------------------------
# Simulation of a Gaussian random field
#-------------------------------------------
sim = grf(nsites, grid = sites, nsim = nsim,
	    cov.model = model, cov.pars = c(variance,phi),
	    nugget = nugget, mean = mean)

mean(sim$data)
var(sim$data)
grid=sim$coords
plot(sim$coords, xlab=expression(X[1]), ylab=expression(X[2]), pch=20)
data =sim$data

# Reading geodata and some descriptive plots

sim_data = as.matrix(cbind(grid, data))
geo_data = as.geodata(sim_data, coords=1:2, var=3)
plot(geo_data, scatter=TRUE)
names(geo_data)
summary(geo_data$data)
stem(geo_data$data)
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")

# Scatterplot using ggplot

data_plot=as.data.frame(sim_data)
ggplot(data_plot, aes(x=data_plot[,1], y=data_plot[,2], size = data_plot[,3])) +
    geom_point(alpha=0.7)+
geom_point(alpha=0.2, shape=21, color="red") +
scale_size(range = c(.1, 3), name="Z")+
theme(legend.position="right") +
    ylab(expression(X[2])) +
    xlab(expression(X[1])) 

#---------------------------------------------------
# Fitting a variogram model to simulated data
# using variofit
#--------------------------------------------------

variogram=variog(geo_data, option="bin")
plot(variogram, xlab="Distance", ylab="Semivariance")
ini.vals =c (2, 8)
variog_estimated = variofit(variogram, ini=ini.vals, cov.model=model, fix.nug=FALSE, wei="npair", min="optim")
plot(variogram, xlab=expression(h), ylab=expression(hat(gamma)(h)), ylim=c(0,4), xlim=c(0,12), 
     col=2, pch=16)  
lines(variog_estimated)

#---------------------------------------------------
# Parameters estimated 
# using variofit
#--------------------------------------------------


#?variofit
names(variog_estimated)
tau2=variog_estimated
sigma2=variog_estimated$cov.pars[1]
phi=variog_estimated$cov.pars[2]


#---------------------------------------------------
# Theoretical  $\Sigma$ matrix
#--------------------------------------------------


sigma=variance
phi=phi
distances=as.matrix(dist(sites, upper=TRUE, diag=TRUE))   
hat_Sigma=cov.spatial(distances, cov.model= model, cov.pars=c(sigma, phi))

#---------------------------------------------------
# $\hat{\Sigma}$
#--------------------------------------------------

tau2=as.numeric(variog_estimated[[1]])
sigma2=variog_estimated$cov.pars[1]
phi_est=variog_estimated$cov.pars[2]
sigma_est=tau2+sigma2
distances=as.matrix(dist(sites, upper=TRUE, diag=TRUE))   
hat_Sigma=cov.spatial(distances, cov.model= model, cov.pars=c(sigma_est, phi_est))



#--------------------------------------------------------------------
# Feasible generailzed least squares estimation of $\mu$
# $\hat{\mu}=(1^T(\hat{\Sigma})^{-1}1)^{-1}(1^T(\hat{\Sigma})^{-1}Z(s))
#-----------------------------------------------------------------------

vector=as.matrix(rep(1, length(sim$data)))
dim(vector)
vector_T=t(vector)
dim(vector_T)
is.matrix(hat_Sigma)
data=as.matrix(data)
dim(data)
hat_mu=solve(vector_T%*%solve(hat_Sigma)%*%vector)%*%(vector_T%*%solve(hat_Sigma)%*%data)
hat_mu

#--------------------------------------------------------------------
# Residuals and influential points
#-----------------------------------------------------------------------


cbind(data, rep(hat_mu, length(data)))
residuals=data-rep(hat_mu, length(data))
sd_res=sd(residuals)
cbind(sites, data, hat_mu[1,1], abs(residuals),ifelse(abs(residuals)>2*sd_res,1,0))


#--------------------------------------------------------------------
# Traditional Hat Matrix 
# $H=1(1^T1)^{-1}1^T
#-----------------------------------------------------------------------

n=nsites
H=vector%*%solve(t(vector)%*%vector)%*%t(vector)
h=NULL
for(i in 1:nsites)
    {
    h[i]=H[i,i]
    }
sum(h)
ifelse(h>2/n, 1,0)
leverage=ifelse(h>2/n,1,0)
cbind(sim$data,round(h,4), leverage)
plot(sim$data, pch=20, xlab="Observation", ylab="Z" )
abline(h=hat_mu, col=2, lwd=2)



#--------------------------------------------------------------------
# Hat Matrix Sigma based on $P$
#-----------------------------------------------------------------------

P= solve(hat_Sigma)%*%vector %*% (solve(vector_T%*%solve(hat_Sigma)%*%vector)) %*% (vector_T%*%solve(hat_Sigma))
dim(P)
round(P,5)
h=NULL
for(i in 1:nsites)
    {
    h[i]=P[i,i]/solve(hat_Sigma)[i,i]
    }
round(h, 5)
sum(h)
plot(h)
abline(h=mean(h), lty=2, col=2)
abline(h=2*mean(h), lty=2, col=2)
leverage=ifelse(h>2*mean(h),1,0)

# Leverage considering the mean
cbind(round(sites, 2), round(sim$data,2), round(h,4),leverage)

# Leverage scaling the h values

h_scaled=h/sum(h)
sum(h_scaled)
plot(h_scaled, xlab="Index", ylab=expression(h))
mean(h_scaled)
abline(h=mean(h_scaled), lty=2, col=2)
abline(h=2*mean(h_scaled), lty=2, col=2)
leverage=ifelse(h_scaled>2*mean(h_scaled),1,0)


# Leverages
leverage=ifelse(h_scaled>2/n,1,0)
cbind(round(sites, 2), round(sim$data,2), round(h_scaled,4),leverage)
plot(sim$data, h_scaled, pch=16, xlab="Z", ylab=expression (h))
abline(h=2/n, lty=2, col=2)



# plot set.seed(5)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[33,1],  sites[33,2],   col=2, pch=16) 
points(sites[34,1], sites[34,2],  col=2, pch=16) 
points(sites[36,1], sites[36,2],  col=2, pch=16) 
points(sites[54,1], sites[54,2],  col=2, pch=16) 
points(sites[64,1], sites[64,2],  col=2, pch=16) 
points(sites[70,1], sites[70,2],  col=2, pch=16) 
points(sites[73,1], sites[73,2],  col=2, pch=16) 
points(sites[86,1], sites[86,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


# plot set.seed(20)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[6,1],  sites[6,2],   col=2, pch=16) 
points(sites[13,1], sites[13,2],  col=2, pch=16) 
points(sites[28,1], sites[28,2],  col=2, pch=16) 
points(sites[31,1], sites[31,2],  col=2, pch=16) 
points(sites[38,1], sites[38,2],  col=2, pch=16) 
points(sites[50,1], sites[50,2],  col=2, pch=16) 
points(sites[57,1], sites[57,2],  col=2, pch=16) 
points(sites[63,1], sites[63,2],  col=2, pch=16) 
points(sites[84,1], sites[84,2],  col=2, pch=16) 
points(sites[86,1], sites[86,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


# plot set.seed(25)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[6,1],  sites[6,2],   col=2, pch=16) 
points(sites[9,1], sites[9,2],  col=2, pch=16) 
points(sites[21,1], sites[21,2],  col=2, pch=16) 
points(sites[41,1], sites[41,2],  col=2, pch=16) 
points(sites[42,1], sites[42,2],  col=2, pch=16) 
points(sites[47,1], sites[47,2],  col=2, pch=16) 
points(sites[78,1], sites[78,2],  col=2, pch=16)
points(sites[92,1], sites[92,2],  col=2, pch=16) 
points(sites[95,1], sites[95,2],  col=2, pch=16) 
points(sites[98,1], sites[98,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")

# plot set.seed(15)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[6,1], sites[6,2],  col=2, pch=16) 
points(sites[8,1],  sites[8,2],   col=2, pch=16) 
points(sites[43,1], sites[43,2],  col=2, pch=16) 
points(sites[50,1], sites[50,2],  col=2, pch=16) 
points(sites[63,1], sites[63,2],  col=2, pch=16) 
points(sites[85,1], sites[85,2],  col=2, pch=16) 
points(sites[92,1], sites[92,2],  col=2, pch=16) 
points(sites[99,1], sites[99,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")



# plot set.seed(85)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[8,1],  sites[8,2],   col=2, pch=16) 
points(sites[18,1], sites[18,2],  col=2, pch=16) 
points(sites[34,1], sites[34,2],  col=2, pch=16) 
points(sites[58,1], sites[58,2],  col=2, pch=16) 
points(sites[65,1], sites[65,2],  col=2, pch=16) 
points(sites[74,1], sites[74,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


stem(sim$data)
plot(density(sim$data))


#-------------------------------------------------------------------------------------
# Using H=\hat\Sigma^{-1/2}1(1^T(\hat{\Sigma})^{-1}1)^{-1}(1^T(\hat{\Sigma})^{-1/2})
#------------------------------------------------------------------------------------

hat_sqrt_solve_sigma=sqrtm(solve(hat_Sigma))
names(hat_sqrt_solve_sigma)
hat_Sigma_half=hat_sqrt_solve_sigma$B
H=solve(hat_Sigma_half)%*%vector %*% (solve(vector_T%*%solve(hat_Sigma)%*%vector)) %*% (vector_T%*%solve(hat_Sigma_half))
dim(H)
h=NULL
for(i in 1:nsites)
    {
    h[i]=H[i,i]
    }
h_scaled=h/sum(h)
sum(h_scaled)
summary(h_scaled)
leverage=ifelse(h_scaled>2/n,1,0)
cbind(sim$data,round(h_scaled,4), leverage)
mean(sim$data)
stem(sim$data)

