
#------------------------------------
# R code. Leverages in Geostatistics
#------------------------------------

rm(list=ls())
#install.packages("plot3D")

#------------
# Libraries
#-----------

library(lattice)
library(geoR)
library(MASS)
library(expm)
library(plot3D)
library(ggplot2)

#---------------------------
# Grid and covariance model
#---------------------------


# Plots in the article are generated using 4 options for set.seed (20, 73, 101, 146)
# You can change this option below to reproduce the plots shown in the article

# set.seed(20) 
# set.seed(73) 
# set.seed(101) 
# set.seed(101)

set.seed(101)
nsites=100
sites=cbind(runif(nsites,0,9), runif(nsites,0,9))
grid=as.matrix(sites)
sigma2=4
phi=10
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)  
distance=dist(sites,diag=T,upper=T)
distance<-as.matrix(distance)
covar = cov.spatial(distance, cov.model="exponential", cov.pars=c(sigma2,phi))
matplot(distance,covar, xlab="Distance", ylab="Covariance", pch=20, col=2)

#---------------
# Spatial trend
#---------------

mu=2
beta1=4
beta2=8
trend=mu+beta1*grid[,1]+beta2*grid[,2]
data=mvrnorm(1,trend,covar)
data=cbind(grid[,1],grid[,2],trend)


#------------------------
# Variogram parameters
#------------------------

variance=sigma2               # $\sigma^2$
phi= phi                      # $\phi$      
nugget= 0                     # $\tao^2$          
model="exponential"           #  variogram model
nsim=1                        # Only one  realization
nsites= dim(sites)[1]         # Number of sites

#------------------------------------------------------
# Simulation of a nonstationary Gaussian random field
#------------------------------------------------------

sim = grf(nsites, grid = sites, nsim = nsim,
	    cov.model = model, cov.pars = c(variance,phi),
	    nugget = nugget, mean = trend)

mean(sim$data)
var(sim$data)
grid=sim$coords
plot(sim$coords, xlab=expression(X[1]), ylab=expression(X[2]), pch=20)
data =sim$data
sim_data = cbind(grid,data)
geo_data = as.geodata(sim_data, coords=1:2, var=3)
plot(geo_data)
names(geo_data)
summary(geo_data$data)
stem(geo_data$data)
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


# Bubble plot simulated data using ggplot
data_plot=as.data.frame(sim_data)
ggplot(data_plot, aes(x=data_plot[,1], y=data_plot[,2], size = data_plot[,3])) +
    geom_point(alpha=0.7)+
geom_point(alpha=0.5, shape=21, color="green") +
scale_size(range = c(.1, 5), name="Z")+
theme(legend.position="right") +
    ylab(expression(X[2])) +
    xlab(expression(X[1])) 



#---------------------------------------------------
# Fitting a variogram model to simulated data
# using variofit
#--------------------------------------------------

#?variofit

variogram=variog(geo_data, trend="1st", option="bin")
plot(variogram, xlab="Distance", ylab="Semivariance")
ini.vals =c (sigma2, phi)
variog_estimated = variofit(variogram, ini=ini.vals, cov.model=model, fix.nugget = FALSE, nugget = 0, min="optim")
variog_estimated
plot(variogram, xlab=expression(h), ylab=expression(hat(gamma)(h)), ylim=c(0,2), xlim=c(0,12),  col=2, pch=16)  
lines(variog_estimated)

#---------------------------------------------------
# Parameters estimated 
# using variofit
#--------------------------------------------------


#variofit
names(variog_estimated)
tau2=variog_estimated
sigma2=variog_estimated$cov.pars[1]
phi=variog_estimated$cov.pars[2]
tau2
sigma2
phi


#------------------------------------------
# Another way of estimating the covariance 
#-----------------------------------------

reg=lm(sim_data[,3]~sim_data[,1]+sim_data[,2])
residuals=reg$residuals
sim_data_residuals = as.matrix(cbind(grid, residuals))
geo_data_residuals = as.geodata(sim_data_residuals, coords=1:2, var=3)
plot(geo_data_residuals)
variogram_residuals=variog(geo_data_residuals, option="bin")
plot(variogram_residuals, xlab="Distance", ylab="Semivariance")
ini.vals =c (2, 8)
variog_estimated_residuals= variofit(variogram, ini=ini.vals, cov.model=model, fix.nug=FALSE, wei="npair", min="optim")
plot(variogram_residuals, xlab=expression(h), ylab=expression(hat(gamma)(h)), ylim=c(0,4), xlim=c(0,12), 
     col=2, pch=16)  
lines(variog_estimated_residuals)
variog_estimated_residuals


#---------------------------------------------------
# Theoretical  $\Sigma$ matrix
#--------------------------------------------------

sigma=variance
phi=phi
distances=as.matrix(dist(sites, upper=TRUE, diag=TRUE))   
hat_Sigma=cov.spatial(distances, cov.model= model, cov.pars=c(sigma, phi))
solve(hat_Sigma)


#---------------------------------------------------
# $\hat{\Sigma}$
#--------------------------------------------------

tau2=as.numeric(variog_estimated[[1]])
sigma2=variog_estimated$cov.pars[1]
phi_est=variog_estimated$cov.pars[2]
sigma_est=tau2+sigma2
distances=as.matrix(dist(sites, upper=TRUE, diag=TRUE))   
hat_Sigma=cov.spatial(distances, cov.model= model, cov.pars=c(sigma_est, phi_est))

#--------------------------------------------------------------------
# Feasible generailzed least squares estimation of $\mu$
# $\hat{\mu}=(1^T(\hat{\Sigma})^{-1}1)^{-1}(1^T(\hat{\Sigma})^{-1}Z(s))
#-----------------------------------------------------------------------

vector=as.matrix(rep(1, length(sim$data)))
X=cbind(vector, grid[,1],grid[,2])
X_T=t(X)
dim(X_T)
is.matrix(hat_Sigma)
data=as.matrix(data)
dim(data)
hat_mu=solve(X_T%*%solve(hat_Sigma)%*%X)%*%(X_T%*%solve(hat_Sigma)%*%data)
hat_mu

#--------------------------------------------------------------------
# Residuals and influential points
#-----------------------------------------------------------------------

hat_Z=hat_mu[1,1]+ hat_mu[2,1]*sites[,1]+hat_mu[3,1]*sites[,2]
cbind(data, hat_Z)
plot(hat_Z, data)
residuals=data-hat_Z
sd_res=sd(residuals)
cbind(sites,hat_Z, data, abs(residuals),ifelse(abs(residuals)>2*sd_res,1,0))

#--------------------------------------------------------------------
# P Matrix
#-----------------------------------------------------------------------


P= solve(hat_Sigma)%*% X%*% (solve(X_T%*%solve(hat_Sigma)%*%X)) %*% (X_T%*%solve(hat_Sigma))
dim(P)
round(P,5)
h=NULL
for(i in 1:nsites)
    {
    h[i]=P[i,i]/solve(hat_Sigma)[i,i]
    }
sum(h)
round(h,4)
mean(h)

# Plot using $h_{ii}=\frac{p_{ii}}{\sigma^{ii}}$
plot(h, xlab="Index", ylab="h")
abline(h=3*mean(h), lty=2,col=2)

# Plot using $h^*_{ii}=\frac{h_{ii}}{\sum h_{ii}}$
# In this case the mean of $h^*_{ii}$ is 1/n

n=100
h_escaled=h/sum(h)
sum(h_escaled)
mean(h_escaled)
plot(h_escaled)
abline(h=3/n, col=2, lty=2)


# Leverages

leverage=ifelse(h>3*mean(h),1,0)
round(cbind(sites, sim$data, round(h,4), leverage),4)
n=length(sim$data)
leverage=ifelse(h_escaled>3/n,1,0)
round(cbind(sites, sim$data, round(h_escaled,4), leverage),4)



#-------------------------------------------
#  plot set.seed(20)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[6,1],   sites[6,2],   col=2, pch=16) 
points(sites[13,1],  sites[13,2],  col=2, pch=16) 
points (sites[28,1], sites[28,2],  col=2, pch=16)
points (sites[31,1], sites[31,2],  col=2, pch=16)
points (sites[38,1], sites[38,2],  col=2, pch=16)
points(sites[50,1],  sites[50,2],  col=2, pch=16)
points(sites[57,1],  sites[57,2],  col=2, pch=16)
points(sites[63,1],  sites[63,2],  col=2, pch=16) 
points(sites[81,1],  sites[81,2],  col=2, pch=16) 
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


#-------------------------------------------
#  plot set.seed(73)
par (mfrow=c(1,2))
plot  (sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[1,1],  sites[1,2],   col=2, pch=16) 
points(sites[15,1], sites[15,2],  col=2, pch=16) 
points(sites[20,1], sites[20,2],  col=2, pch=16) 
points(sites[25,1], sites[25,2],  col=2, pch=16) 
points(sites[54,1], sites[54,2],  col=2, pch=16) 
points(sites[93,1], sites[93,2],  col=2, pch=16)
points(sites[97,1], sites[97,2],  col=2, pch=16)
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")


#-------------------------------------------
#  plot set.seed(101)
par (mfrow=c(1,2))
plot  (sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[2,1],  sites[2,2],   col=2, pch=16) 
points(sites[8,1],  sites[8,2],   col=2, pch=16) 
points(sites[64,1], sites[64,2],  col=2, pch=16) 
points(sites[72,1], sites[72,2],  col=2, pch=16) 
points(sites[76,1], sites[76,2],  col=2, pch=16) 
points(sites[77,1], sites[77,2],  col=2, pch=16)
points(sites[84,1], sites[84,2],  col=2, pch=16)
points(sites[86,1], sites[86,2],  col=2, pch=16)
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")



#-------------------------------------------
#  plot set.seed(146)
par (mfrow=c(1,2))
plot(sites, xlab=expression(X[1]), ylab=expression(X[2]), cex.lab=0.9, pch=20)
points(sites[7,1],  sites[7,2],  col=2, pch=16)
points(sites[12,1], sites[12,2],  col=2, pch=16)  
points(sites[28,1], sites[28,2],  col=2, pch=16) 
points(sites[37,1], sites[37,2],  col=2, pch=16)
points(sites[46,1], sites[46,2],  col=2, pch=16)
points(sites[48,1], sites[48,2],  col=2, pch=16)
points(sites[74,1], sites[74,2],  col=2, pch=16)
points(sites[79,1], sites[79,2],  col=2, pch=16)
points(sites[89,1], sites[89,2],  col=2, pch=16)
points(sites[95,1], sites[95,2],  col=2, pch=16)
points(geo_data, xlab=expression(X[1]), ylab=expression(X[2]), col="blue")



par(mfrow=c(1,2))
# Plot respect to X1
sim.data=as.matrix(sim_data)
plot(sim_data[,1],   sim_data[,3],    xlab=expression(X[2]), ylab=expression(Z), pch=16)
points(sites[7, 1],  sim_data[7,3],   col=2, pch=16) 
points(sites[12,1],  sim_data[12,3],  col=2, pch=16) 
points(sites[28,1],  sim_data[28,3],  col=2, pch=16) 
points(sites[37,1],  sim_data[37,3],  col=2, pch=16)
points(sites[46,1],  sim_data[46,3],  col=2, pch=16)
points(sites[48,1],  sim_data[48,3],  col=2, pch=16)
points(sites[74,1],  sim_data[74,3],  col=2, pch=16)
points(sites[79,1],  sim_data[79,3],  col=2, pch=16) 
points(sites[89,1],  sim_data[89,3],  col=2, pch=16)
points(sites[95,1],  sim_data[95,3],  col=2, pch=16)


# Plot respect to X2
sim.data=as.matrix(sim_data)
plot(sim_data[,2],  sim_data[,3],    xlab=expression(X[2]), ylab=expression(Z), pch=16)
points(sites[7,2],  sim_data[7,3],   col=2, pch=16) 
points(sites[12,2], sim_data[12,3],  col=2, pch=16) 
points(sites[28,2], sim_data[28,3],  col=2, pch=16) 
points(sites[37,2], sim_data[37,3],  col=2, pch=16)
points(sites[46,2], sim_data[46,3],  col=2, pch=16)
points(sites[48,2], sim_data[48,3],  col=2, pch=16)
points(sites[74,2], sim_data[74,3],  col=2, pch=16)
points(sites[79,2], sim_data[79,3],  col=2, pch=16) 
points(sites[89,2], sim_data[89,3],  col=2, pch=16)
points(sites[95,2], sim_data[95,3],  col=2, pch=16)




#------------------------------------------------------------------------------------
# 3D Plot sed.seed (12)
scatter3D(sites[,1], sites[,2], sim$data, phi = 0, bty = "g",  
          pch = 20, cex = 2, ticktype = "detailed",
          xlab = expression(X1),
          ylab = expression(X2), zlab = "Z")
scatter3D(x = sim_data[9,1], y = sim_data[9,2], z = sim_data[9,3], add = TRUE, colkey = FALSE, 
          pch = 20, cex = 2, col = "black")
scatter3D(x = sim_data[33,1], y = sim_data[33,2], z = sim_data[33,3], add = TRUE, colkey = FALSE, 
          pch = 20, cex = 2, col = "black")
scatter3D(x = sim_data[35,1], y = sim_data[35,2], z = sim_data[35,3], add = TRUE, colkey = FALSE, 
          pch = 20, cex = 2, col = "black")
scatter3D(x = sim_data[63,1], y = sim_data[63,2], z = sim_data[63,3], add = TRUE, colkey = FALSE, 
          pch = 20, cex = 2, col = "black")
scatter3D(x = sim_data[98,1], y = sim_data[98,2], z = sim_data[98,3], add = TRUE, colkey = FALSE, 
          pch = 20, cex = 2, col = "black")


