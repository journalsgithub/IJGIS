

# ------------------
# Reading data
# -------------------

rm(list=ls())
library(geoR)
library(sm)
depth = read.table("depth.txt", head=T)
attach(depth)
plot(East,North)
summary(Depth)
var(Depth)
sd(Depth)
hist(Depth, freq=FALSE, breaks=9, xlab="Depth (m)", 
    ylab="Frequency", main="", col=2)
boxplot(Depth, col=2, horizontal=TRUE)
par(mfrow=c(1,2))
hist(Depth, freq=FALSE, breaks=9, xlab="Depth(m)", 
    ylab="Frequency", main="", col=2)
boxplot(Depth, col=2, horizontal=TRUE)
stem(Depth)

par(mfrow=c(1,2))
plot(East, Depth, xlab="East", ylab="Depth (m)")
plot(North, Depth, xlab="North", ylab="Depth (m)")



# --------------------------
# Reading geodata
#---------------------------

depth <- read.geodata("depth.txt", head=T, coords.col=1:2, data.col=3)
depth.border <- read.table("cienaga.border", head=T)
depth.border <- rbind(depth.border, depth.border[1,])
plot(depth.border)
is.list(depth)
class(depth)
summary(depth$data)

# .................................................................
# Exploratory analysis
# .................................................................

plot(depth, bord=depth.border)
win.graph()
plot(depth, bord=depth.border, lambda=1)
plot(depth, bord=depth.border, lambda=1, scatter3d=T)

      
# .................................................................
# Other descriptive functions
# .................................................................

win.graph()
points(depth, bord=depth.border, col=2, xlab="Easting", ylab="Northing")
win.graph()
args(points.geodata)
points(depth, bord=depth.border, cex.min=1, cex.max=1, pt.div="quartile", xlab="Easting", ylab="Northing")
win.graph()
points(depth, bord=depth.border, cex.min=1, cex.max=1,col=gray(seq(0.9,0,l=length(depth$data))), xlab="Easting", ylab="Northing")
win.graph()
points(depth, bord=depth.border, cex.min=1, cex.max=1, col=gray(seq(0.9,0,l=length(depth$data))), xlab="Easting", ylab="Northing")


# -----------------
# Variogram
# -------------------

# -------------
# Cloud
# --------------

cloud1 <- variog(depth, option = "cloud", max.dist = 25000)
cloud2 <- variog(depth, option = "cloud", estimator.type = "modulus", max.dist = 25000)
cloud3=variog(depth, trend="1st", option = "cloud", max.dist = 25000)

# .................................................................
# Classical and madogram
# .................................................................

bin1 = variog(depth, uvec = seq(0, 25000, l = 10))
bin2 = variog(depth, uvec = seq(0, 25000, l = 10), estimator.type = "modulus")
bin3 = variog(depth, trend="1st", uvec = seq(0, 25000, l = 10))

# .................................................................
# Plots 
# .................................................................

par(mfrow = c(1, 2))
plot(cloud1, xlab="Distancia (m)",ylab="Variogram", main = "Classical")
plot(cloud2, xlab="Distancia (m)",ylab="Variogram",main = "Madogram")
plot(cloud3, xlab="Distancia (m)",ylab="Variogram", main = "Classical")
plot(bin1, xlab="Distancia (m)",ylab="Variogram",main = "Classical")
plot(bin2, xlab="Distancia (m)",ylab="Variogram",main = "Madogram")
plot(bin3, xlab="Distancia (m)",ylab="Variogram",main = "Classical")

# .................................................................
# 4.4 Omnidirectional
# .................................................................

depth.v1= variog(depth, max.dist=25000, uvec = seq(0, 25000, l = 10), xlab="Distancia (m)",ylab="Variogram",main = "Classical") #Hace lo mismo que bin1
depth.v2= variog(depth, xlab="Distancia (m)",ylab="Variogram",main = "Madogram", uvec = seq(0, 25000, l = 10), estimator.type = "modulus")#Hace lo mismo que bin2
win.graph()
par(mfrow = c(2, 1))
plot(depth.v1)
plot(depth.v2)

# .................................................................
# 4.5 Directional
# .................................................................

win.graph()
par(mfrow = c(2, 1))
plot(variog4(depth, maxdist=20000))
plot(variog4(depth, maxdist=20000, estimator.type = "modulus"))

# .................................................................
# 4.6 Box-Plot
# .................................................................

bin1 = variog(depth, uvec = seq(0, 25000, l = 10), bin.cloud = T)
bin2 = variog(depth, uvec = seq(0, 25000, l = 10), estimator.type = "modulus", bin.cloud = T)
par(mfrow = c(1, 2))
plot(bin1, bin.cloud = T, main = "Classical")
plot(bin2, bin.cloud = T, main = "Modulus")


# --------------
# Monte Carlo
# ---------------

depth.env=variog.mc.env(depth, obj=depth.v1)
win.graph()
plot(depth.v1, env=depth.env)

# ----------------------------------
# Fitting the model
# -----------------------------------------

# .........................................................
# Least squares Kapa = 0.5 (exponential model)
# .........................................................

ini.vals = expand.grid(seq(0.08,0.14,l=5), seq(2000,20000,l=10))
depth.ols1 = variofit(bin1, ini=ini.vals, fix.nug=FALSE, cov.model= "exponential", wei="equal", min="optim")
depth.ols2 = variofit(bin2, ini=ini.vals, fix.nug=FALSE, wei="equal", min="optim")
depth.wls1 = variofit(bin1, ini=ini.vals, fix.nug=FALSE, wei="npair", min="optim")
depth.wls2 = variofit(bin2, ini=ini.vals, fix.nug=FALSE, wei="npair", min="optim")
depth.ols1
depth.ols2
depth.wls1
depth.wls2
win.graph()

par(mfrow = c(1, 2))
plot(bin1, ylab=expression(hat(gamma)(h)), xlab=expression(h), main="", ylim=c(0,0.2), col=2, pch=16)
lines(depth.ols1)
lines(depth.wls1)
plot(bin2, ylab=expression(hat(gamma)(h)), xlab=expression(h), main="", ylim=c(0,0.2), cex=0.8,col=2, pch=16)
lines(depth.ols2)
lines(depth.wls2)


# .................................................................
# Ordinary kriging
# .................................................................

depth.grid=expand.grid(East=seq(953000,980000,1000), North=seq(1670000,1710000,1000))
plot(depth.grid)
lines(depth.border,col=2, lwd=2)
points(East, North, col=4, lwd=2)

depth.kc=krige.conv(depth, loc=depth.grid, bord=depth.border, krige= krige.control(nugget=0,cov.model="exponential", cov.pars=c(sigmasq=0.14, phi= 4000)))
depth.kc=krige.conv(depth, loc=depth.grid, bord=depth.border, krige= krige.control(nugget=0.0423, cov.model="exponential", cov.pars=c(sigmasq=0.1798, phi= 16411)))
par(mfrow=c(1,2))
image(depth.kc, main="kriging estimates", xlab="East", ylab="North")
contour(depth.kc,main="kriging estimates", add=TRUE, drawlabels=TRUE)
#win.graph()
image(depth.kc, val=sqrt(depth.kc$krige.var), main="kriging estimates", col=terrain.colors(100))
contour(depth.kc, val=sqrt(depth.kc$krige.var), main="kriging estimates", add=TRUE, drawlabels=TRUE)

liminf=depth.kc$predict-1.645*sqrt(depth.kc$krige.var)
limsup=depth.kc$predict+1.645*sqrt(depth.kc$krige.var)
intervals=cbind(liminf,limsup)
intervals




#--------------
# Leverages
#---------------


#---------------------------------------
# Parameters estimated  using variofit
#------------------------------------


names(depth.ols2)
tau2=depth.ols2[[1]]
sigma_est=depth.ols2$cov.pars[1]
phi_est=depth.ols2$cov.pars[2]


#-----------------------------
# covariance matrix
#----------------------------

sites=depth$coords
dim(sites)
distances=as.matrix(dist(sites, upper=TRUE, diag=TRUE))   
max(distances)
hat_Sigma=cov.spatial(distances, cov.model= "exponential", cov.pars=c(sigma_est, phi_est))


#--------------------------------------------------------------------
# Feasible generailzed least squares estimation of $\mu$
# $\hat{\mu}=(1^T(\hat{\Sigma})^{-1}1)^{-1}(1^T(\hat{\Sigma})^{-1}Z(s))
#-----------------------------------------------------------------------

vector=as.matrix(rep(1, length(depth$data)))
dim(vector)
vector_T=t(vector)
dim(vector_T)
is.matrix(hat_Sigma)
data=depth$data
data=as.matrix(data)
dim(data)
hat_mu=solve(vector_T%*%solve(hat_Sigma)%*%vector)%*%(vector_T%*%solve(hat_Sigma)%*%data)
hat_mu
nsites=length(depth$data)
n=nsites


# Traditional Variance

hat_Sigma[1,1]/n

# Variance of  $\hat{\mu}$

solve(vector_T%*%solve(hat_Sigma)%*%vector)
sqrt(solve(vector_T%*%solve(hat_Sigma)%*%vector))

# Confidence interval
hat_mu-1.645*sqrt(solve(vector_T%*%solve(hat_Sigma)%*%vector))
hat_mu+1.645*sqrt(solve(vector_T%*%solve(hat_Sigma)%*%vector))


#--------------------------------------------------------------------
# Hat Matrix Sigma based on $P$
#-----------------------------------------------------------------------

P= solve(hat_Sigma)%*%vector %*% (solve(vector_T%*%solve(hat_Sigma)%*%vector)) %*% (vector_T%*%solve(hat_Sigma))
dim(P)
round(P,5)
h=NULL
for(i in 1:nsites)
    {
    h[i]=P[i,i]/solve(hat_Sigma)[i,i]
    }
round(h, 5)
h_escaled=h/sum(h)
sum(h_escaled)
mean(h_escaled)
plot(density(h_escaled))
abline(v=2/n, lty=2)
abline(v=quantile(h_escaled, prob=0.95), lty=2, col=2)
abline(v=2*mean(h_escaled), col=3)


# Leverages
leverage=ifelse(h_escaled>2/n,1,0)
cbind(round(sites, 4), round(data,4), round(h_escaled,4),leverage)


# Bubble plot
par (mfrow=c(1,2))
plot(sites, xlab="Easting", ylab="Northing", cex.lab=0.9, pch=20)
points(sites[1,1],    sites[1,2],   col=2, pch=16) 
points(sites[2,1],    sites[2,2],   col=2, pch=16) 
points(sites[6,1],    sites[6,2],   col=2, pch=16) 
points(sites[28,1],   sites[28,2],  col=2, pch=16) 
points(sites[39,1],   sites[39,2],  col=2, pch=16) 
points(sites[40,1],   sites[40,2],  col=2, pch=16) 
points(sites[78,1],   sites[78,2],  col=2, pch=16) 
points(sites[92,1],   sites[92,2],  col=2, pch=16) 
points(sites[110,1],  sites[110,2], col=2, pch=16) 
points(sites[114,1],  sites[114,2], col=2, pch=16) 
points(depth, xlab="Easting", ylab="Northing", col="blue")


